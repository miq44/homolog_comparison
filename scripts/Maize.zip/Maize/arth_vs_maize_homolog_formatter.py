in_file= open('Arabidopsis_Maize_Homolog.txt').readlines()
out = open('Arabidopsis_Thaliana_vs_Maize_homolog.txt','w')
out.write('Arabidopsis_Thaliana_Gene_Id\tMaize_Gene_Id\n')
for line in in_file:
    line=line.rstrip().split('\t')
    arth_gene = line[0].split('.')[0]
    maize_gene = line[1]
    
    if maize_gene[:2] == 'GR':
        maize_gene = maize_gene.split('_')[0]
    else:
        maize_gene=maize_gene.replace("FGP","FG")
    out.write(arth_gene+"\t"+maize_gene+'\n')
out.close()
    
    
    