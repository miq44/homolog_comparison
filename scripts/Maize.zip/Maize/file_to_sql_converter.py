import sys

file_name = sys.argv[1]
input_file = open(file_name).readlines()


table_name = file_name.split(".")[0]
out = open(table_name+".sql","w")

header = input_file[0]

columns = header.rstrip().split('\t')

sql = 'CREATE TABLE `hl_'+table_name+'` ( `'+columns[0]+'` varchar(100) NOT NULL,'
for item in columns[1:]:
    line = '`'+item+'` DOUBLE NOT NULL,'
    sql+=line
sql = sql[:-1]+' ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;'
out.write(sql+"\n")

column_name =",".join([ '`'+column+'`' for column in columns])

sql = 'INSERT INTO `hl_'+table_name+'` ( '+column_name+' ) \nVALUES\n '
for line in input_file[1:]:
    line = line.rstrip().split('\t')
    str_id = "'"+line[0]+"'"
    line = ','.join(line[1:])
    sql+= "(" +str_id+","+line+'),\n'
sql = sql[:-2]+';'
out.write(sql)    
out.close()





