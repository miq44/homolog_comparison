family = open('GSE6583_family.soft').readlines()
mapping = {}
for line in family[105:22851]:
    line = line.rstrip().split('\t')
    entry_id = line[0].strip('"')
    gene_id = line[1].strip('"')
    if gene_id[0:2] == 'At':
        mapping[entry_id] = gene_id       


matrix = open('GSE6583_series_matrix.txt').readlines()
out = open('Arabidopsis_Thaliana_Drought_FPKM.csv','w')
column_info = matrix[27]
column_info = column_info.rstrip().split('\t')
column_info = [info.strip('"').replace(" ","_") for info in column_info]
header = 'Gene_Id,'+column_info[1]+','+column_info[3]+','+column_info[5]+','+column_info[2]+','+column_info[4]+','+column_info[6]+','+column_info[7]+','+column_info[9]+','+column_info[11]+','+column_info[8]+','+column_info[10]+','+column_info[12]+'\n'
out.write(header)
for line in matrix[64:22875]:
    line = line.rstrip().split('\t')
    entry_id = line[0].strip('"')
    if entry_id in mapping:
        out.write(mapping[entry_id]+','+line[1]+','+line[3]+','+line[5]+','+line[2]+','+line[4]+','+line[6]+','+line[7]+','+line[9]+','+line[11]+','+line[8]+','+line[10]+','+line[12]+'\n')
out.close()

